// function defination style
int add(int x, int y){
  return x + y;
}

// Anonymous function
Function fn = (x,y){
  return x + y;
};

// Fat Arrow Function
Function fn2 = (x,y)=>x+y;