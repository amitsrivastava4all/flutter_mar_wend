import 'dart:io';
//import 'dart:core'; // Optional

void main(){
  int a = 10;
  stdout.write("Hello Dart\n");
  print("A is "+a.toString());
  print("A is $a");
  print("A is ${a+1}");
  print(a); // print in new line
   // print in same line
}