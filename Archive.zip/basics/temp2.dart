void main(){
  var t = [10,20,30,40,"amit", true,[10,20]];
  List<int> temp = [10,20,30];
 // int result = temp.fold(0,(sum,ele)=>sum+ele);
 //int result = temp.reduce((sum,ele)=>sum+ele);
 //List<int> temp2 = t.cast();
  //temp2.forEach((int element) =>print(element));
  List<int> tt = [100,2000];
  List<int> t3 = [1,2,3];
  List<int> t5 = [111,1222,444];
  List<String> names = ["amit", "rAM", "tIm", "tOm"];
  //print(names.contains("ram")?"Found":"Not Found");
  print(names.where((String name) => name.toLowerCase() == "ram").length>0?"Found":"Not Found");
  List<String> titleNames = names.map((String name)=>name[0].toUpperCase()+name.substring(1).toLowerCase()).toList();
  print(titleNames);
  List<List<int>> t4 = [tt, t3, t5];

  Iterable<int> itr = t5.whereType();
  List<int> i6 = List.filled(100, 0);
  i6.fillRange(1, 9, 1000);
  print(i6);
  // Iterator<int> i = itr.iterator;
  // while(i.moveNext()){
  //   print(i.current);
  // }
  for(int i in t5){
    print(i);
  }

  //t5.forEach((element) { })
  List<int> flatList = t4.expand(( element) => element).toList();
  print(flatList);

  

}