void main(){
  if(10>2){
    print("10 is Greater");
  }
  else{
    print("2 is Greater");
  }
  int choice = 1;
  switch(choice){
    case 1:
      print("One");
      break;
      case 2:
      print("Two");
      break;
      default:
      print("Nothing...");
  }
  for(var i = 1; i<=10; i++){
    print(i);
  }
  int i = 1;
  while(i<=10){
    i++;
  }
}