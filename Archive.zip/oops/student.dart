class Student{
  late int noOfClasses ;
  late int rollno; // Members of a class , When they come in Memory
  // When object is created or Instance a created..
  // It is also called Instance variables
  late String name;
  late double marks;
  late String grade;
  //Default Constructor
  Student(){
    print("I am Default Cons ");
    rollno = 1;
    name = "A";
    marks = 90.0;
    grade="A";
    noOfClasses = 20;
  } 
  Student.takeInput(int rollno, String name, double marks, String grade, int noOfClasses){
      this.rollno = rollno ; // Instance Var = Local Var
      this.name = name;
      this.marks = marks;
      this.grade = grade;
      this.noOfClasses = noOfClasses;

  }
  void printIt(){
    print("Rollno $rollno Name $name Marks $marks Grade $grade");
  }
}


void main(){
  //Student ram = new Student(); // ram is a reference variable
  //Student ram  = Student(); // Calling Default Cons or UnNamed / ClassName
  Student ram = Student.takeInput(1001, "Ram", 90, "A", 60);

  // new is optional to write
  ram.printIt(); // dot operator we are accessing the members
  //String x;
  //int y;
}