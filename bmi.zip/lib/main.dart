import 'package:flutter/material.dart';
import 'package:layout_demo/screens/bmi.dart';
import 'package:layout_demo/screens/expandeddemo.dart';
import 'package:layout_demo/screens/gapp.dart';
import 'package:layout_demo/screens/stackdemo.dart';
import 'package:layout_demo/screens/ted.dart';
import 'package:layout_demo/screens/vertdiv.dart';
import 'package:layout_demo/utils/theme.dart';

void main() {
  runApp(MaterialApp(theme: getTheme(), home: BMI()));
  //home: GApp(),
  //home: TedApp()));
  // home: StackDemo()));
}
