class Product {
  int id;
  String name;
  String desc;
  String message;
  Product(this.id, this.name, this.desc, this.message);
}
