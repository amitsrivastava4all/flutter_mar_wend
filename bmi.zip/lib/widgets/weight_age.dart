import 'package:flutter/material.dart';
import 'package:layout_demo/widgets/buttons.dart';

class WeightAge extends StatelessWidget {
  const WeightAge({Key? key}) : super(key: key);

  _getTextStyle({double fontSize = 30}) {
    return TextStyle(fontSize: fontSize, color: Colors.white);
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(10),
        padding: EdgeInsets.all(20),
        color: Colors.grey.shade800,
        child: Column(
          children: [
            Text(
              'WEIGHT',
              style: _getTextStyle(fontSize: 20),
            ),
            Text(
              "60",
              style: _getTextStyle(),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [Buttons(), Buttons()],
            )
          ],
        ),
      ),
    );
  }
}
