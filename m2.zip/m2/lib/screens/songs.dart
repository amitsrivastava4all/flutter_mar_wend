import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:musicapp/models/song_model.dart';
import 'package:musicapp/repository/songsclient.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class Songs extends StatefulWidget {
  const Songs({Key? key}) : super(key: key);

  @override
  _SongsState createState() => _SongsState();
}

class _SongsState extends State<Songs> {
  AudioPlayer audioPlayer = AudioPlayer();
  List<SongModel> songs = [];
  List<Widget> widgets = [];
  bool isPlaying = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getSongs();
  }

  _getSongs({String singerName = "Daler Mehndi"}) {
    Future<http.Response> future = SongClient.getSongsBySingerName(singerName);
    // Success Result / Success Response (JSON String)
    future.then((value) {
      print(" Data is ${value.body.runtimeType}"); // string
      var obj = convert.jsonDecode(value.body); // string to object
      print("Result is ${obj['results']}");
      List<dynamic> list = obj['results'];
      songs = convertObjectIntoSongObjects(list);
      //print(obj['results'][3]['previewUrl']);
      //print(obj.runtimeType);
    }).
        // Fail Response (Network Error)
        catchError((err) => print("Error is $err"));
  }

  List<SongModel> convertObjectIntoSongObjects(List list) {
    // Convert object into song list
    songs = list.map((singleObject) {
      SongModel song = SongModel.from(singleObject);
      return song;
    }).toList();
    widgets = printAllSongs();
    setState(() {});
    return songs;
  }

  _playPause(SongModel song) {
    if (isPlaying) {
      audioPlayer.pause();
    } else {
      audioPlayer.play(song.audioURL);
    }
    isPlaying = !isPlaying;
    song.isPlaying = isPlaying;

    setState(() {});
    print("######### IsPlaying $isPlaying ");
  }

  List<Widget> printAllSongs() {
    return songs.map((SongModel song) {
      print("IsPlaying $isPlaying");
      return ListTile(
        leading: Image.network(song.imageURL),
        title: Text(
          song.trackName,
          style: TextStyle(color: Colors.white),
        ),
        subtitle: Text(song.artistName, style: TextStyle(color: Colors.white)),
        trailing: IconButton(
          onPressed: () {
            _playPause(song);
          },
          icon: Icon(
            (song.isPlaying ? Icons.pause : Icons.play_arrow),
            color: Colors.yellow,
            size: 30,
          ),
        ),
      );
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(child: Column(children: printAllSongs())),
      appBar: AppBar(
          backgroundColor: Colors.grey.shade100,
          title: Text(
            'Songs',
            style: TextStyle(color: Colors.black),
          )),
    );
  }
}
