package com.brainmentors.flutter_firebase_example.flutter_firebase_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
