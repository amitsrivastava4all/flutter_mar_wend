import 'package:eval_ex/expression.dart';
import 'package:flutter/material.dart';

class Calc extends StatefulWidget {
  const Calc({Key? key}) : super(key: key);

  @override
  _CalcState createState() => _CalcState();
}

class _CalcState extends State<Calc> {
  String? currentValue;
  String textValue = "";

  GestureDetector equalButton(String number) {
    return GestureDetector(
      onTap: () {
        Expression exp = Expression(tc.text);
        tc.text = exp.eval().toString();
      },
      child: Container(
        width: 120,
        height: 120,
        child: Center(
          child: Text(
            number,
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
        ),
        decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle),
      ),
    );
  }

  GestureDetector _digitButton(String number) {
    return GestureDetector(
      onTap: () {
        currentValue = number;
        tc.text = tc.text + (currentValue ?? "");
        setState(() {});
      },
      child: Container(
        width: 70,
        height: 70,
        child: Center(
          child: Text(
            number,
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
        ),
        decoration: BoxDecoration(color: Colors.black, shape: BoxShape.circle),
      ),
    );
  }

  GestureDetector _operatorButton(String number) {
    return GestureDetector(
      onTap: () {
        currentValue = number;
        tc.text = tc.text + (currentValue ?? "");
        setState(() {});
      },
      child: Container(
        width: 70,
        height: 70,
        child: Center(
          child: Text(
            number,
            style: TextStyle(fontSize: 30, color: Colors.black),
          ),
        ),
        decoration: BoxDecoration(color: Colors.orange, shape: BoxShape.circle),
      ),
    );
  }

  TextEditingController tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Column(
        children: [
          Container(
            margin: EdgeInsets.all(10),
            child: TextField(
              controller: tc,
              style: TextStyle(fontSize: 30),
              decoration: InputDecoration(
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10))),
            ),
          ),
          SizedBox(
            height: 100,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _digitButton("1"),
              _digitButton("2"),
              _digitButton("3"),
              _operatorButton("+")
            ],
          ),
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _digitButton("4"),
              _digitButton("5"),
              _digitButton("6"),
              _operatorButton("-")
            ],
          ),
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _digitButton("7"),
              _digitButton("8"),
              _digitButton("9"),
              _operatorButton("*")
            ],
          ),
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [equalButton("=")],
          )
        ],
      )),
    );
  }
}
