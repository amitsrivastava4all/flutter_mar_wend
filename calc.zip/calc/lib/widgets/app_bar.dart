import 'package:flutter/material.dart';

getTedAppbar(String first, String second) {
  return AppBar(
    actions: [
      Icon(
        Icons.more_vert,
        size: 30,
      ),
      SizedBox(
        width: 20,
      )
    ],
    elevation: 0,
    backgroundColor: Colors.transparent,
    title: Row(
      children: [
        Text(
          '$first  ',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
        ),
        Text(
          second,
          style: TextStyle(color: Colors.red),
        )
      ],
    ),
  );
}
