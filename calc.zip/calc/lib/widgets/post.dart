import 'package:flutter/material.dart';

class PostWidget extends StatelessWidget {
  const PostWidget({Key? key}) : super(key: key);

  _getStyle({double fontSize = 14}) {
    return TextStyle(color: Colors.white, fontSize: fontSize);
  }

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.all(3),
      child: Stack(
        children: [
          Image.network(
              'https://tedxwinterpark.com/wp-content/uploads/2019/11/Best-TED-Talks-From-The-Curator-Himself-.jpg'),
          Positioned(
              bottom: 20,
              left: 0,
              width: deviceSize.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    children: [
                      Text(
                        'Ram Kumar',
                        style: _getStyle(),
                      ),
                      Text(
                        'Flutter vs React Native',
                        style: _getStyle(fontSize: 20),
                      )
                    ],
                  ),
                  Column(
                    children: [
                      Icon(
                        Icons.more_vert,
                        color: Colors.white,
                      ),
                      Text(
                        '11:45',
                        style: _getStyle(),
                      )
                    ],
                  )
                ],
              ))
        ],
      ),
    );
  }
}
