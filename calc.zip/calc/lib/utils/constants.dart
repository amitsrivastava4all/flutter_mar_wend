class Constants {
  static String LOCAL_IMAGE = "assets/images/salad.png";
  static String IMAGE_2 =
      "https://library.kissclipart.com/20190227/woe/kissclipart-plate-clipart-caesar-salad-vegetarian-cuisine-reci-1c03617842116123.png";
  static String IMAGE_1 =
      "https://banner.uclipart.com/20200112/oxa/salad-dish-vegetable.png";
}
