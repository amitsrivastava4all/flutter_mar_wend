import 'package:emi_ap/widgets/field.dart';
import 'package:flutter/material.dart';

class Emi extends StatefulWidget {
  const Emi({Key? key}) : super(key: key);

  @override
  _EmiState createState() => _EmiState();
}

class _EmiState extends State<Emi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          children: [
            Field(
                label: 'Home Loan Amount',
                iconData: Icons.currency_exchange,
                range: 200),
            Field(label: 'Interest Rate', iconData: Icons.percent, range: 20),
            Field(
                label: 'Loan Tenure',
                iconData: Icons.calendar_view_day,
                range: 30)
          ],
        ),
      )),
    );
  }
}
