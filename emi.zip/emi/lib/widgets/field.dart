import 'package:flutter/material.dart';

class Field extends StatelessWidget {
  String label;
  IconData iconData;
  double range;
  late double currentValue = 0.0;

  Field({required this.label, required this.iconData, required this.range});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Column(children: [
        Row(
          children: [
            Expanded(child: Text(label)),
            Expanded(
              flex: 2,
              child: TextField(
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    suffixIcon: Icon(iconData)),
              ),
            )
          ],
        ),
        Slider(
            value: currentValue,
            min: 0,
            max: range,
            onChanged: (double value) {})
      ]),
    );
  }
}
