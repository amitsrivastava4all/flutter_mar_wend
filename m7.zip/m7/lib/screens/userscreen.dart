import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:musicapp/repository/user_operations.dart';

class UserScreen extends StatefulWidget {
  const UserScreen({Key? key}) : super(key: key);

  @override
  _UserScreenState createState() => _UserScreenState();
}

class _UserScreenState extends State<UserScreen> {
  TextEditingController loginEmail = TextEditingController();
  TextEditingController loginPwd = TextEditingController();
  _showLogin() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.network(
            'https://www.yippinorders.com/webstart/assets/img/yippin_login.png'),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            controller: loginEmail,
            decoration: InputDecoration(
                prefixIcon: Icon(Icons.email),
                hintText: 'Type Email Here',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        BorderSide(width: 3, style: BorderStyle.solid))),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            controller: loginPwd,
            obscureText: true,
            obscuringCharacter: "&",
            decoration: InputDecoration(
                prefixIcon: Icon(Icons.password),
                hintText: 'Type Password Here',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        BorderSide(width: 3, style: BorderStyle.solid))),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            MaterialButton(
              child: Text(
                'Login',
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
              onPressed: () {
                _doLogin();
              },
              elevation: 5,
              minWidth: 100,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              color: Colors.blueAccent,
            )
          ],
        )
      ],
    );
    // return Text(
    //   'I am the Login',
    //   style: TextStyle(fontSize: 40),
    // );
  }

  TextEditingController regEmail = TextEditingController();
  TextEditingController regPwd = TextEditingController();
  _showRegister() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.network(
            'https://5.imimg.com/data5/CJ/GF/IV/SELLER-3920885/call-register-service-crs--500x500.png'),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            controller: regEmail,
            decoration: InputDecoration(
                prefixIcon: Icon(Icons.email),
                hintText: 'Type Email Here',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        BorderSide(width: 3, style: BorderStyle.solid))),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            controller: regPwd,
            obscureText: true,
            //obscuringCharacter: "&",
            decoration: InputDecoration(
                prefixIcon: Icon(Icons.password),
                hintText: 'Type Password Here',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        BorderSide(width: 3, style: BorderStyle.solid))),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            MaterialButton(
              child: Text(
                'Register',
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
              onPressed: () {
                _doRegister();
              },
              elevation: 5,
              minWidth: 100,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              color: Colors.blueAccent,
            )
          ],
        )
      ],
    );
  }

  initState() {
    super.initState();
    _checkConnectivity();
  }

  _loadPages() {
    return [_showLogin, _showRegister];
  }

  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        onTap: (int index) {
          _index = index;
          setState(() {});
        },
        items: const [
          BottomNavigationBarItem(label: 'Login', icon: Icon(Icons.login)),
          BottomNavigationBarItem(label: 'Register', icon: Icon(Icons.add))
        ],
      ),
      body: SafeArea(
        child: Container(
          child: _loadPages()[_index](),
        ),
      ),
    );
  }

  _showMessage(String msg) async {
    await Fluttertoast.showToast(
        msg: msg,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);
  }

  UserOperations _opr = UserOperations();
  void _doRegister() async {
    String email = regEmail.text;
    String password = regPwd.text;
    try {
      String fireBaseRegEmailId = await _opr.register(email, password);
      _showMessage("Register SuccessFully $fireBaseRegEmailId");
    } catch (e) {
      _showMessage("Register Fails $e");
      print("Some Exception Generated During Reg $e");
    }
  }

  late StreamSubscription subscription;
  _checkConnectivity() {
    subscription = Connectivity()
        .onConnectivityChanged
        .listen((ConnectivityResult result) {
      // Got a new connectivity status!
      if (result == ConnectivityResult.none) {
        _showMessage("no internet connection ");
      } else if (result == ConnectivityResult.wifi) {
        _showMessage("Connected to wifi ");
      }
      if (result == ConnectivityResult.mobile) {
        _showMessage("Connected to mobile data ");
      }
    });
  }

  void _doLogin() async {
    try {
      String result = await _opr.login(loginEmail.text, loginPwd.text);

      if (result.length > 0) {
        _showMessage("Login SuccessFully....");
      } else {
        _showMessage("Invalid Userid or Password");
      }
    } catch (e) {
      _showMessage("Invalid Userid or Password");
    }
  }
}
