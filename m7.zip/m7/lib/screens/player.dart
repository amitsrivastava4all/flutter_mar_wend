import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:musicapp/models/song_model.dart';

class Player extends StatefulWidget {
  SongModel songModel;
  Player(this.songModel);

  @override
  _PlayerState createState() => _PlayerState();
}

class _PlayerState extends State<Player> {
  AudioPlayer _audioPlayer = AudioPlayer();
  bool isPlay = false;
  late Duration _duration = Duration(milliseconds: 0);
  late Duration _position = Duration(milliseconds: 0); // null
  String message = "";

  _registerEvents() {
    // Total Audio Time
    _audioPlayer.onDurationChanged.listen((Duration d) {
      print('Max duration: $d');
      setState(() => _duration = d);
    });

    // Current Time
    _audioPlayer.onAudioPositionChanged.listen((Duration p) {
      setState(() => _position = p);
    });
    // Status of the Song.
    _audioPlayer.onPlayerStateChanged.listen((PlayerState s) {
      print('Current player state: $s');
      setState(() => message = s.name);
    });
    // Song Finish
    _audioPlayer.onPlayerCompletion.listen((event) {
      setState(() {
        message = "Song Finish";
        isPlay = false;
        _position = _duration;
      });
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _registerEvents();
  }

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Scaffold(
      //backgroundColor: Colors.pink,
      // appBar: AppBar(
      //   backgroundColor: Colors.transparent,
      //   elevation: 0,
      // ),
      body: Column(children: [
        Container(
          child: Column(children: [
            SizedBox(height: 30),
            _backButton(context),
            _circleImage(),
          ]),
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [Colors.pink, Colors.black, Colors.redAccent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight)),
          height: deviceSize.height / 2,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text((_position.inSeconds.toString())),
              seekBar(),
              Text((_duration.inSeconds).toInt().toString())
            ],
          ),
        ),
        SizedBox(
          height: 20,
        ),
        _audioControls(),
        SizedBox(height: 70),
        Text(
          message,
          style: TextStyle(fontSize: 30),
        )
      ]),
    );
  }

  Container _audioControls() {
    return Container(
      width: 200,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        //mainAxisSize: MainAxisSize.min,
        children: [
          Expanded(
            flex: 1,
            child: IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.arrow_back_rounded,
                  color: Colors.pink,
                  size: 50,
                )),
          ),
          Expanded(
            flex: 2,
            child: IconButton(
                onPressed: () async {
                  if (isPlay) {
                    await _audioPlayer.pause();
                  } else {
                    await _audioPlayer.play(widget.songModel.audioURL);
                  }
                  isPlay = !isPlay;
                  setState(() {});
                },
                icon: Icon(
                  isPlay ? Icons.pause_circle_filled : Icons.play_circle_fill,
                  color: Colors.pink,
                  size: 70,
                )),
          ),
          Expanded(
            flex: 1,
            child: IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.forward_rounded,
                  color: Colors.pink,
                  size: 50,
                )),
          )
        ],
      ),
    );
  }

  CircleAvatar _circleImage() {
    return CircleAvatar(
      maxRadius: 100,
      backgroundImage: NetworkImage(widget.songModel.imageURL),
    );
  }

  Row _backButton(BuildContext context) {
    return Row(
      children: [
        IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
        ),
        SizedBox(
          height: 100,
          width: 100,
        ),
      ],
    );
  }

  Slider seekBar() {
    return Slider(
      value: (_position != null &&
              _duration != null &&
              _position.inMilliseconds < _duration.inMilliseconds)
          ? _position.inMilliseconds / _duration.inMilliseconds
          : 0.0,
      onChanged: (double currentValue) {
        print("Current Value $currentValue");
        if (_position != null) {
          int poistion = (currentValue * _duration.inMilliseconds).toInt();
          print("Pos $poistion");
          _audioPlayer.seek(Duration(milliseconds: poistion.round()));
        }
      },
      activeColor: Colors.redAccent,
      inactiveColor: Colors.black,
    );
  }
}
