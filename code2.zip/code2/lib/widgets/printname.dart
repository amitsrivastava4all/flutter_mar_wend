import 'package:flutter/material.dart';

class PrintName extends StatelessWidget {
  late String textValue;
  late Function fn;
  PrintName(this.textValue, this.fn);

  _makeUpper() {
    textValue = textValue.toUpperCase();
    fn(textValue); // Call Parent Function
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
            margin: EdgeInsets.all(10),
            child: Text(
              'Child Name $textValue',
              style: TextStyle(fontSize: 20),
            )),
        ElevatedButton(
            onPressed: () {
              _makeUpper();
            },
            child: Text('Upper'))
      ],
    );
  }
}
