import 'package:flutter/material.dart';

class Buttons extends StatelessWidget {
  const Buttons({Key? key}) : super(key: key);
  _getTextStyle({double fontSize = 30}) {
    return TextStyle(fontSize: fontSize, color: Colors.white);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(5),
      child: Center(
        child: Text(
          '+',
          style: _getTextStyle(),
        ),
      ),
      width: 50,
      height: 50,
      decoration: BoxDecoration(color: Colors.grey, shape: BoxShape.circle),
    );
  }
}
