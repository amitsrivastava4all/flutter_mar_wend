import 'dart:math';

import 'package:eval_ex/expression.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Calc extends StatefulWidget {
  const Calc({Key? key}) : super(key: key);

  @override
  _CalcState createState() => _CalcState();
}

class _CalcState extends State<Calc> {
  String? currentValue;
  String textValue = "";
  bool isOperator = false;
  @override
  initState() {
    super.initState();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
  }

  GestureDetector equalButton(String number) {
    return GestureDetector(
      onTap: () {
        String expression = tc.text;
        expression = expression.replaceAll("x", "*");
        Expression exp = Expression(expression);
        tc.text = exp.eval().toString();
      },
      child: Container(
        width: 120,
        height: 120,
        child: Center(
          child: Text(
            number,
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
        ),
        decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle),
      ),
    );
  }

  GestureDetector clearButton(String number) {
    return GestureDetector(
      onTap: () {
        tc.text = "";
        setState(() {});
      },
      child: Container(
        width: 120,
        height: 120,
        child: Center(
          child: Text(
            number,
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
        ),
        decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle),
      ),
    );
  }

  GestureDetector _digitButton(String number) {
    return GestureDetector(
      onTap: () {
        isOperator = false;
        currentValue = number;
        tc.text = tc.text + (currentValue ?? "");
        setState(() {});
      },
      child: Container(
        width: 70,
        height: 70,
        child: Center(
          child: Text(
            number,
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
        ),
        decoration: BoxDecoration(color: Colors.black, shape: BoxShape.circle),
      ),
    );
  }

  plusMinus(String sign) {
    return GestureDetector(
      onTap: () {
        tc.text = (int.parse(tc.text!) * -1).toString();

        setState(() {});
      },
      child: Container(
        width: 70,
        height: 70,
        child: Center(
          child: Text(
            sign,
            style: TextStyle(fontSize: 30, color: Colors.black),
          ),
        ),
        decoration: BoxDecoration(color: Colors.orange, shape: BoxShape.circle),
      ),
    );
  }

  GestureDetector _operatorButton(String number) {
    return GestureDetector(
      onTap: () {
        if (isOperator) {
          String expression = tc.text;
          expression = expression.substring(0, expression.length - 1);
          print("Expression Value is $expression");
          expression = expression + number;
          print("Now Expression is $expression");
          tc.text = expression;
          return;
        }
        currentValue = number;
        tc.text = tc.text + (currentValue ?? "");
        isOperator = true;
        setState(() {});
      },
      child: Container(
        width: 70,
        height: 70,
        child: Center(
          child: Text(
            number,
            style: TextStyle(fontSize: 30, color: Colors.black),
          ),
        ),
        decoration: BoxDecoration(color: Colors.orange, shape: BoxShape.circle),
      ),
    );
  }

  TextEditingController tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(10),
              child: TextField(
                controller: tc,
                style: TextStyle(fontSize: 30),
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10))),
              ),
            ),
            SizedBox(
              height: 100,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _digitButton("1"),
                _digitButton("2"),
                _digitButton("3"),
                _operatorButton("+")
              ],
            ),
            SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _digitButton("4"),
                _digitButton("5"),
                _digitButton("6"),
                _operatorButton("-")
              ],
            ),
            SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _digitButton("7"),
                _digitButton("8"),
                _digitButton("9"),
                _operatorButton("x")
              ],
            ),
            SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                equalButton("="),
                _operatorButton("/"),
                clearButton("AC"),
                plusMinus("+/-")
              ],
            )
          ],
        ),
      )),
    );
  }
}
