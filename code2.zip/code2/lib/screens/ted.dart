import 'package:flutter/material.dart';
import 'package:layout_demo/widgets/app_bar.dart';
import 'package:layout_demo/widgets/post.dart';

class TedApp extends StatelessWidget {
  const TedApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: getTedAppbar('TED', 'Talks'),
      body: SingleChildScrollView(
        child: Column(
          children: [PostWidget(), PostWidget(), PostWidget(), PostWidget()],
        ),
      ),
    );
  }
}
