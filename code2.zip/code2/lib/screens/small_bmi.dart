import 'package:flutter/material.dart';

class Bmi extends StatefulWidget {
  const Bmi({Key? key}) : super(key: key);

  @override
  _BmiState createState() => _BmiState();
}

class _BmiState extends State<Bmi> {
  int sliderValue = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Column(
        children: [
          Text(
            sliderValue.toString(),
            style: TextStyle(
                //fontFamily: '',
                fontSize: 40),
          ),
          Slider(
              min: 0,
              max: 100,
              value: sliderValue.toDouble(),
              onChanged: (double currentValue) {
                sliderValue = currentValue.toInt();
                setState(() {});
              })
        ],
      )),
    );
  }
}
