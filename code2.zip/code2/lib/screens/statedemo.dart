// State (Data) 1 Class
// View (UI) 1 Class
import 'package:flutter/material.dart';
import 'package:layout_demo/widgets/printname.dart';
import 'dart:math';

class StateDemo extends StatefulWidget {
  const StateDemo({Key? key}) : super(key: key);

  @override
  _StateDemoState createState() => _StateDemoState();
}

class _StateDemoState extends State<StateDemo> {
  late String textValue; // State
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    textValue = "";
  }

  recieveChildValue(String val) {
    textValue = val; // val contains the value pass from the child
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('State Demo')),
      body: Column(
        children: [
          PrintName(textValue,
              recieveChildValue), // Passing data and Function to the Child Widget
          // Text(
          //   'Name $textValue',
          //   style: TextStyle(fontSize: 20),
          // ),
          TextField(
            onChanged: (String val) {
              print("Value Rec $val");
              textValue = val;
              setState(() {});
            },
            decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                hintText: 'Type Your Name'),
          )
        ],
      ),
    );
  }
}
