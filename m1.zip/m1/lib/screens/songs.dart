import 'package:flutter/material.dart';
import 'package:musicapp/repository/songsclient.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class Songs extends StatefulWidget {
  const Songs({Key? key}) : super(key: key);

  @override
  _SongsState createState() => _SongsState();
}

class _SongsState extends State<Songs> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future<http.Response> future =
        SongClient.getSongsBySingerName('Sonu Nigam');
    future.then((value) {
      print(" Data is ${value.body.runtimeType}");
      var obj = convert.jsonDecode(value.body);
      print(obj['results'][3]['previewUrl']);
      print(obj.runtimeType);
    }).catchError((err) => print("Error is $err"));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.grey.shade100,
          title: Text(
            'Songs',
            style: TextStyle(color: Colors.black),
          )),
    );
  }
}
