import 'package:flutter/material.dart';

class RowLayout extends StatelessWidget {
  const RowLayout({Key? key}) : super(key: key);

  Container _getContainer(
      {double width = 100,
      double height = 100,
      Color myColor = Colors.redAccent}) {
    return Container(
      width: width,
      height: height,
      color: myColor,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            _getContainer(myColor: Colors.green, width: 50, height: 50),
            _getContainer(),
            _getContainer(myColor: Colors.blue, width: 70, height: 70)
          ],
        ),
      ),
    );
  }
}
