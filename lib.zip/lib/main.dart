import 'package:first_app/page.dart';
import 'package:first_app/page2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: RowLayout()
      // debugShowCheckedModeBanner: false,
      //     home: Container(
      //   child: Text('Hello Flutter'),
      //   color: Colors.amberAccent,
      // )
      // home: SafeArea(child: Text('Hello Flutter')),
      ));
}
