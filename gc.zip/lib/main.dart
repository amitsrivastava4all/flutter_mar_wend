import 'package:flutter/material.dart';
import 'package:layout_demo/screens/gapp.dart';
import 'package:layout_demo/utils/theme.dart';

void main() {
  runApp(MaterialApp(
    theme: getTheme(),
    home: GApp(),
  ));
}
