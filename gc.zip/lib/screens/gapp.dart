import 'package:flutter/material.dart';
import 'package:layout_demo/widgets/product.dart';
//import 'package:google_fonts/google_fonts.dart';

class GApp extends StatelessWidget {
  const GApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SingleChildScrollView(
        child: Column(
          children: [Product(), Product(), Product(), Product()],
        ),
      ),
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(160),
        child: AppBar(
          flexibleSpace: Container(
            height: 300,
            width: 300,
            margin: EdgeInsets.only(bottom: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  'meal',
                  style: TextStyle(fontSize: 30),
                  //style: GoogleFonts.pacifico(),
                ),
                Text('Here are 5 Meals')
              ],
            ),
          ),
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.grey.shade100,
        ),
      ),
    );
  }
}

// class GApp extends StatelessWidget {
//   _prepareText(String msg, {double fontSize = 14}) {
//     return Text(
//       msg,
//       style: TextStyle(fontSize: fontSize),
//     );
//   }

//   _prepareBox(
//       {double width = 50, double height = 50, Color color = Colors.red}) {
//     return Container(
//       width: width,
//       height: height,
//       color: color,
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     // TODO: implement build
//     // UI Rendering Logic
//     return Scaffold(
//       body: SafeArea(
//           child:
//               /*Row(
//           //textBaseline: TextBaseline.alphabetic,
//           mainAxisSize: MainAxisSize.max,
//           crossAxisAlignment: CrossAxisAlignment.baseline,
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             _prepareText('Hello', fontSize: 30),
//             _prepareText('Hi'),
//             _prepareText('Ok', fontSize: 50)
//           ],
//         ),*/
//               Column(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         crossAxisAlignment: CrossAxisAlignment.end,
//         children: [
//           _prepareBox(width: 100, height: 100, color: Colors.purple),
//           _prepareBox(width: 70, height: 70, color: Colors.green),
//           _prepareBox()
//         ],
//       )),
//     );
//   }
// }
