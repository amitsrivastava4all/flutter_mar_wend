import 'package:firebase_auth/firebase_auth.dart';

class UserOperations {
  FirebaseAuth _auth =
      FirebaseAuth.instance; // Instance Create of FireBase Auth
  login(String email, String password) {}

  Future<String> register(String email, String password) async {
    UserCredential userCred = await _auth.createUserWithEmailAndPassword(
        email: email, password: password);
    User user = userCred.user!;
    String emailId = user.email!;
    return emailId;
  }
}
