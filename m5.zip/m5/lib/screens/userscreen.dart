import 'package:flutter/material.dart';

class UserScreen extends StatefulWidget {
  const UserScreen({Key? key}) : super(key: key);

  @override
  _UserScreenState createState() => _UserScreenState();
}

class _UserScreenState extends State<UserScreen> {
  _showLogin() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.network(
            'https://www.yippinorders.com/webstart/assets/img/yippin_login.png'),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            decoration: InputDecoration(
                prefixIcon: Icon(Icons.email),
                hintText: 'Type Email Here',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        BorderSide(width: 3, style: BorderStyle.solid))),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            obscureText: true,
            obscuringCharacter: "&",
            decoration: InputDecoration(
                prefixIcon: Icon(Icons.password),
                hintText: 'Type Password Here',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                        BorderSide(width: 3, style: BorderStyle.solid))),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            MaterialButton(
              child: Text(
                'Login',
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
              onPressed: () {},
              elevation: 5,
              minWidth: 100,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              color: Colors.blueAccent,
            )
          ],
        )
      ],
    );
    // return Text(
    //   'I am the Login',
    //   style: TextStyle(fontSize: 40),
    // );
  }

  _showRegister() {
    return Text(
      "I am the Register",
      style: TextStyle(fontSize: 40),
    );
  }

  initState() {
    super.initState();
  }

  _loadPages() {
    return [_showLogin, _showRegister];
  }

  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        onTap: (int index) {
          _index = index;
          setState(() {});
        },
        items: const [
          BottomNavigationBarItem(label: 'Login', icon: Icon(Icons.login)),
          BottomNavigationBarItem(label: 'Register', icon: Icon(Icons.add))
        ],
      ),
      body: SafeArea(
        child: Container(
          child: _loadPages()[_index](),
        ),
      ),
    );
  }
}
