import 'package:flutter/material.dart';
import 'package:musicapp/screens/songs.dart';
import 'package:musicapp/screens/userscreen.dart';

void main() {
  runApp(MaterialApp(
      // home: Songs(),
      home: UserScreen()));
}
