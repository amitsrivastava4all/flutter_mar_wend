import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:musicapp/models/song_model.dart';

class Player extends StatefulWidget {
  SongModel songModel;
  Player(this.songModel);

  @override
  _PlayerState createState() => _PlayerState();
}

class _PlayerState extends State<Player> {
  AudioPlayer _audioPlayer = AudioPlayer();
  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Scaffold(
      //backgroundColor: Colors.pink,
      // appBar: AppBar(
      //   backgroundColor: Colors.transparent,
      //   elevation: 0,
      // ),
      body: Column(children: [
        Container(
          child: Column(children: [
            SizedBox(height: 30),
            Row(
              children: [
                IconButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  icon: Icon(Icons.arrow_back),
                  color: Colors.white,
                ),
                SizedBox(
                  height: 100,
                  width: 100,
                ),
              ],
            ),
            CircleAvatar(
              maxRadius: 100,
              backgroundImage: NetworkImage(widget.songModel.imageURL),
            ),
          ]),
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [Colors.pink, Colors.black, Colors.redAccent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight)),
          height: deviceSize.height / 2,
        ),
        Slider(
          value: 1,
          onChanged: (double currentValue) {},
          min: 1,
          max: 30,
          activeColor: Colors.redAccent,
          inactiveColor: Colors.black,
        ),
        SizedBox(
          height: 20,
        ),
        Container(
          width: 200,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            //mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                flex: 1,
                child: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.arrow_back_rounded,
                      color: Colors.pink,
                      size: 50,
                    )),
              ),
              Expanded(
                flex: 2,
                child: IconButton(
                    onPressed: () async {
                      await _audioPlayer.play(widget.songModel.audioURL);
                    },
                    icon: Icon(
                      Icons.play_circle_fill,
                      color: Colors.pink,
                      size: 70,
                    )),
              ),
              Expanded(
                flex: 1,
                child: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.forward_rounded,
                      color: Colors.pink,
                      size: 50,
                    )),
              )
            ],
          ),
        )
      ]),
    );
  }
}
