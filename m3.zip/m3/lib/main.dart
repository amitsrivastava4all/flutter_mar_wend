import 'package:flutter/material.dart';
import 'package:musicapp/screens/songs.dart';

void main() {
  runApp(MaterialApp(
    home: Songs(),
  ));
}
