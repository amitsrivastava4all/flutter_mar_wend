import 'package:flutter/material.dart';

class VertDiv extends StatelessWidget {
  const VertDiv({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: 100,
          child: Row(
            children: [
              Text('Hi    '),
              Container(
                height: 20,
                width: 1,
                color: Colors.black,
              ),
              Text('   Hello')
            ],
          ),
        ),
      ),
    );
  }
}
