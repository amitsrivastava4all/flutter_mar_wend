import 'package:flutter/material.dart';

class StackDemo extends StatelessWidget {
  const StackDemo({Key? key}) : super(key: key);
  _getContainer(
      {double width = 100, double height = 100, Color color = Colors.red}) {
    return Container(
      width: width,
      height: height,
      color: color,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow,
      body: SafeArea(
        child: Stack(
          //fit: StackFit.expand,
          //fit: StackFit.loose,
          children: [
            Positioned(
                right: 150,
                bottom: 150,
                height: 300,
                width: 300,
                child: _getContainer(
                    height: 300, width: 300, color: Colors.green)),
            Positioned(
              child: _getContainer(height: 150, width: 150, color: Colors.blue),
              top: 50,
              left: 10,
              width: 150,
              height: 150,
            ),
            Positioned(
                child: _getContainer(),
                top: 200,
                right: 100,
                width: 100,
                height: 100),
          ],
        ),
      ),
    );
  }
}
