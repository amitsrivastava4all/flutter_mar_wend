import 'package:flutter/material.dart';

class ExpandedDemo extends StatelessWidget {
  const ExpandedDemo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: Row(
        children: [
          Expanded(
              flex: 3,
              child: Image.network(
                  'https://cdn.britannica.com/49/182849-050-4C7FE34F/scene-Iron-Man.jpg')),
          Expanded(
            flex: 1,
            child: Image.network(
                'https://img.mensxp.com/media/content/2020/Sep/header-credit-Marvel-Studios_5f741da26f175.jpeg'),
          )
        ],
      ),
    ));
  }
}
