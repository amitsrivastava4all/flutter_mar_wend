import 'package:flutter/material.dart';
import 'package:layout_demo/widgets/gender.dart';
import 'package:layout_demo/widgets/height.dart';
import 'package:layout_demo/widgets/title.dart';
import 'package:layout_demo/widgets/weight_age.dart';

class BMI extends StatelessWidget {
  const BMI({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            TitleWidget('bmi calc'),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              GenderWidget(icon: Icons.male, name: 'Male'),
              GenderWidget(icon: Icons.female, name: 'Female'),
            ]),
            HeightWidget(),
            Row(
              children: [WeightAge(), WeightAge()],
            ),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(10),
              child: Center(
                child: Text(
                  'CALCULATE',
                  style: TextStyle(fontSize: 40, color: Colors.white),
                ),
              ),
              decoration: BoxDecoration(color: Colors.red),
            )
          ],
        ),
      ),
    );
  }
}
