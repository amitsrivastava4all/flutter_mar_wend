import 'package:flutter/material.dart';
import 'package:layout_demo/utils/constants.dart';

class Product extends StatelessWidget {
  const Product({Key? key}) : super(key: key);

  _prepareText(String txt,
      {double fontSize = 14, FontWeight fontWeight = FontWeight.normal}) {
    return Text(
      txt,
      maxLines: 4,

      //softWrap: true,
      style: TextStyle(fontSize: fontSize, fontWeight: fontWeight),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      margin: EdgeInsets.all(10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            flex: 1,
            child: CircleAvatar(
              maxRadius: 70,
              backgroundImage: AssetImage(Constants.LOCAL_IMAGE),
              //backgroundImage: NetworkImage(Constants.IMAGE_1),
            ),
            // child: Container(
            //   child: Image.network(
            //     Constants.IMAGE_1,
            //     fit: BoxFit.contain,
            //   ),
            // ),
          ),
          Expanded(
            flex: 2,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  width: 20,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _prepareText('Pasta Dish Morning',
                        fontSize: 20, fontWeight: FontWeight.bold),
                    _prepareText(
                        'ffdfsdfsdfsfs fsdffd fjdfhk \n fshdjkfsdh fsdhkjfsd fshfk'),
                    SizedBox(
                      width: 150,
                      height: 10,
                      child: Divider(
                        color: Colors.grey,
                        thickness: 2,
                      ),
                    ),
                    Row(
                      children: [
                        _prepareText('Replace this dish', fontSize: 14),
                        SizedBox(
                          width: 30,
                        ),
                        Icon(Icons.kitchen),
                        Icon(Icons.access_alarm)
                      ],
                    )
                  ],
                ),
              ],
            ),
          )
        ],
      ),
      decoration: BoxDecoration(
          boxShadow: [BoxShadow(color: Colors.black, blurRadius: 10)],
          color: Colors.white),
    );
  }
}
