import 'package:flutter/material.dart';

class Box extends StatelessWidget {
  bool isXorZero;
  int position;
  Function updatePosForParent;
  Box(
      {required this.isXorZero,
      required this.position,
      required this.updatePosForParent});

  printXorZero() {
    updatePosForParent(
        position); // Call parent function and passing the current position
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Expanded(
        flex: 1,
        child: Container(
          margin: EdgeInsets.all(10),
          width: 100,
          height: 100,
          child: Center(
              child:
                  Text(isXorZero ? "X" : "0", style: TextStyle(fontSize: 30))),
          decoration: BoxDecoration(
              boxShadow: [BoxShadow(color: Colors.black, blurRadius: 20)],
              color: Colors.cyan),
        ),
      ),
    );
  }
}
