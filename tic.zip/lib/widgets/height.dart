import 'package:flutter/material.dart';

class HeightWidget extends StatelessWidget {
  const HeightWidget({Key? key}) : super(key: key);

  _getTextStyle({double fontSize = 30}) {
    return TextStyle(fontSize: fontSize, color: Colors.white);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(color: Colors.grey.shade800),
      child: Column(
        children: [
          Text(
            'HEIGHT',
            style: _getTextStyle(),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                '180',
                style: _getTextStyle(fontSize: 24),
              ),
              Text(
                'cm',
                style: _getTextStyle(fontSize: 14),
              )
            ],
          ),
          Slider(
              inactiveColor: Colors.grey,
              activeColor: Colors.white,
              thumbColor: Colors.redAccent,
              min: 1,
              max: 200,
              value: 1,
              onChanged: (_value) {})
        ],
      ),
    );
  }
}
