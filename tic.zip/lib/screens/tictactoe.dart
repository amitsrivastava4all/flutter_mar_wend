import 'package:flutter/material.dart';
import 'package:layout_demo/widgets/box.dart';

class TicTacToe extends StatefulWidget {
  const TicTacToe({Key? key}) : super(key: key);

  @override
  _TicTacToeState createState() => _TicTacToeState();
}

class _TicTacToeState extends State<TicTacToe> {
  late bool flag;
  late int currentPosition;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    flag = true;
    currentPosition = 0;
  }

  updatePosition(int pos) {
    currentPosition = pos;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow.shade200,
      body: SafeArea(
          child: Center(
        child: Container(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Tic Tac Toe Game ',
              style: TextStyle(fontSize: 40),
            ),
            ..._createRow()
          ],
        )),
      )),
    );
  }

  List<Widget> _createRow() {
    int noOfRows = 3;
    List<Widget> list = [];
    for (int i = 1; i <= noOfRows; i++) {
      list.add(Row(
        children: _createBox(),
      ));
    }
    return list;
  }

  int posCount = 1;
  List<Widget> _createBox() {
    int noOfBox = 3;
    List<Widget> boxes = [];
    for (int i = 1; i <= noOfBox; i++) {
      boxes.add(Box(
        isXorZero: flag,
        position: posCount,
        updatePosForParent: updatePosition,
      ));
      posCount++;
    }
    return boxes;
  }
}
