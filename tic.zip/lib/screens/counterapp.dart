// StateFul Widget -
import 'package:flutter/material.dart';

class CounterApp extends StatefulWidget {
  const CounterApp({Key? key}) : super(key: key);

  @override
  _CounterAppState createState() => _CounterAppState();
}

// It is a Private Class
class _CounterAppState extends State<CounterApp> {
  late int _count;

  @override
  initState() {
    print("One time call....");
    _count = 0;
  }

  plus() {
    _count++;
    print("Count is $_count");
    setState(() {});
  }

  // All the UI Rendering will be happen in build function
  // When ever State change build willbe called.
  // This class need state , all the state info coming from the CounterApp Class.
  @override
  Widget build(BuildContext context) {
    print("n time call...");
    return Scaffold(
        floatingActionButtonLocation: FloatingActionButtonLocation.centerTop,
        floatingActionButton: FloatingActionButton(
            backgroundColor: Colors.green,
            onPressed: () {
              plus();
            },
            child: Padding(
              padding: EdgeInsets.all(10),
              child: Icon(
                Icons.add,
                size: 40,
              ),
            )),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Counter $_count',
                style: TextStyle(fontSize: 40),
              ),
              GestureDetector(
                onTap: () {
                  plus();
                },
                child: Container(
                    width: 100,
                    height: 100,
                    child: Icon(Icons.add),
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(color: Colors.black, blurRadius: 10)
                      ],
                      color: Colors.green,
                      shape: BoxShape.circle,
                    )),
              )
            ],
          ),
        ),
        appBar: AppBar(
          backgroundColor: Colors.redAccent,
          title: Text(
            'Counter App',
            style: TextStyle(fontSize: 24, color: Colors.white),
          ),
        ));
  }
}
