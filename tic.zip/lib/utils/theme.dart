import 'package:flutter/material.dart';

getTheme() {
  return ThemeData(appBarTheme: AppBarTheme(foregroundColor: Colors.black));
}
