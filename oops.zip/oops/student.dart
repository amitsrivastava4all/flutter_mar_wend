// S O L I D
// S - SRP - Single Responsiblity principle
class Student {
  late int _noOfClasses;
  // late int rollno; // these are public in scope.
  // _rollno - private - Scope with in the file / library
  late int _rollno; // Members of a class , When they come in Memory
  // When object is created or Instance a created..
  // It is also called Instance variables
  late String _name;
  late double _marks;
  late String _grade;
  get name => this._name;

  set name(value) => this._name = value;

  get marks => this._marks;

  set marks(value) => this._marks = value;

  get grade => this._grade;

  set grade(value) => this._grade = value;

  //Default Constructor
  // Constructor call - To Initalise the instance variables
  // Every class has (UnNamed Constructor) default constructor by default (No Args)
  Student() {
    print("I am Default Cons ");
    _rollno = 1;
    _name = "A";
    _marks = 90.0;
    _grade = "A";
    _noOfClasses = 20;
  }

  // set marks(double marks) {
  //   if (marks <= 0) {
  //     print("Marks Not Allowed  to Set");
  //     return;
  //   }
  //   _marks = marks;
  // }

  // double get marks => _marks;

  // Named Constructor - ClassName.nameoftheconstructor
  // Student.takeInput(
  //     int rollno, String name, double marks, String grade, int noOfClasses) {
  //   this._rollno = rollno; // Instance Var = Local Var
  //   this._name = name;
  //   this._marks = marks;
  //   this._grade = grade;
  //   this._noOfClasses = noOfClasses;
  // }
  Student.takeInput(
      this._rollno, this._name, this._marks, this._grade, this._noOfClasses);

  void printIt() {
    print("Rollno $_rollno Name $_name Marks $_marks Grade $_grade");
  }
}
