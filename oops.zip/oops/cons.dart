class A {
  A() {
    print("I am a default cons");
  }
  A._abcd() {
    print("I am a a Private Cons");
  }
  // A.redirect() : this._abcd(); // Redirect constructor
  A.redirect() : this();
}
