import './student.dart';

void main() {
  //Student ram = new Student(); // ram is a reference variable
  //Student ram  = Student(); // Calling Default Cons or UnNamed / ClassName
  //Student ram = Student.takeInput(1001, "Ram", 90, "A", 60);
  Student ram = Student(); // Has - a
  ram.marks = -99; // call setter
  print(ram.marks); // call getter
  //ram._rollno = -1001;
  //ram._marks = -999;
  //ram._name = "";
  // new is optional to write
  ram.printIt(); // dot operator we are accessing the members
  //String x;
  //int y;
}
