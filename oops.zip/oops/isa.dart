class Parent {
  int? x;
  Parent() {
    x = 10;
    print("Parent cons call");
  }
  Parent.namedParentCons() {
    print("I am a Named Cons");
    x = 20;
  }
  void show() {
    print(" I am the Show Fn...");
  }
}

class Child extends Parent {
  late int y;
  //int x = 1;
  //Child(int x) :super(){ // Implicit call
  Child(int x) {
    print("Child Cons Call " + super.x.toString());
    y = 20 + super.x! + x; // this.x
    print("Y is $y");
  }
  @override
  void show() {
    super.show(); // parent method call
    print("I am the child show...");
  }

  Child.namedCons() : super.namedParentCons() {
    // Explicit call
    print(" I am the Child Named Cons");
  }
}

main() {
  //Child c = Child(2); // UnNamed Cons Call
  Child c = Child.namedCons();
  c.show();
}
